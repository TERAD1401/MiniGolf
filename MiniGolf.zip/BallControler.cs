using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallControler : MonoBehaviour
{
    public Rigidbody rb;
    Camera mainCamera;

    public float stopvelocity;
    public float shotPower;
    public float maxPower;

    bool isAiming;
    bool isIdle;
    bool isShooting;

    vector3 worldPoint;
    
    void Awake()
    {
        mainCamera = Camera.main;
        rb.maxAngularvelocity = 1000;
        isAiming = false;
    }

    void Update()
    {
        if (rb.velocity.magnitude < stopvelocity)
        {
            processAim();

            if (Input.GetMouseButtonDown(0))
            {
                if (isIdle) isAiming =true;
            }

            if (Input.GetMouseButtonUp(0))
            {
                isShooting = true;
            }
        }
    }

    void FixedUpdate()
    {
        if (rb.velocity.magnitude < stopvelocity)
        {
            stop();
        }

        if (isShooting)
        {
            Shoot(worldPoint.Value);
            isShooting = false;
        }
    }

    private void processAim()
    {
        if (isAiming && isIdle) return;

        worldPoint = CastMouseClickRay();

        if (!worldPoint.HasValue) return;
    }

    private vector3 CastMouseClickRay()
    {
        Ray ray = mainCamera.ScreenPointRoRay(Input.mousePosition);

        if(Physics.Raycast(ray, out RaycastHit hit)) return hit.point;
        else return null;
    }

    private void Stop()
    {
        rb.velocity = vector3.zero;
        rb.angularvelocity = vector3.zero;

        isIdle = true;
    }

    private void Shoot(vector3 point)
    {
        isAiming = false;

        vector3 horizontalWorldPoint = new vector3(point.x, transform.position.y, point.z);

        vector3 direction = (horizontalWorldPoint - transform.position).normalized;
        float strength = vector3.Distance(transform.position, horizontalWorldPoint);
        rb.AddForce(direction * strength * shotPower);
    }
}
